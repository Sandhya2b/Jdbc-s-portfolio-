const api="/api/students";

async function loadStudents(){
  const res=await fetch(api);
  const students=await res.json();
  document.getElementById("studentList").innerHTML=students.map(s=>`
    <tr><td>${s.id}</td><td>${s.name}</td><td>${s.course}</td><td>${s.email}</td>
    <td><button class="delete" onclick="deleteStudent(${s.id})">Delete</button></td></tr>`).join("");
}
document.getElementById("studentForm").addEventListener("submit",async e=>{
  e.preventDefault();
  const student={name:name.value,course:course.value,email:email.value};
  const res=await fetch(api,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(student)});
  alert(await res.text()); e.target.reset(); loadStudents();
});
async function deleteStudent(id){
  if(confirm("Delete this student?")){
    const res=await fetch(`${api}/${id}`,{method:"DELETE"});
    alert(await res.text()); loadStudents();
  }
}
loadStudents();
